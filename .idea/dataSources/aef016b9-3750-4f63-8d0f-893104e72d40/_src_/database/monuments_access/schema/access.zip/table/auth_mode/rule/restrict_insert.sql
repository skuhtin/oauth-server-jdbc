CREATE RULE restrict_insert AS
    ON INSERT TO access.auth_mode DO INSTEAD NOTHING;