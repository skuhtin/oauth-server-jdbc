CREATE RULE restrict_delete AS
    ON DELETE TO access.auth_mode DO INSTEAD NOTHING;